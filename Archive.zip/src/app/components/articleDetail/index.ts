export * from './articleDetail.component'
