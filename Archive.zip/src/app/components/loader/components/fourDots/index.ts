export * from './fourDots.component';
