export * from './detail.component'
