export * from './zoomSlider.component'
