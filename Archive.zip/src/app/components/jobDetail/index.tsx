export * from './jobDetail.component'
