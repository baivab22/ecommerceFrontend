export * from './mainCarousel.component'
