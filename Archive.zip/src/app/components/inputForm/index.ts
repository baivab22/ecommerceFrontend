export * from './inputForm.component'
