export * from './dragArea.component'
