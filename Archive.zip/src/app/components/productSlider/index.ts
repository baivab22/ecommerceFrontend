export * from './productSlider.component'
