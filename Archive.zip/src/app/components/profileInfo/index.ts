export * from './profileInfo.component'
