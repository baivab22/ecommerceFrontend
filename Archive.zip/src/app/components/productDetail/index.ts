export * from './productDetail.component'
