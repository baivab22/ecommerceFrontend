export * from './businessDetail.component'
