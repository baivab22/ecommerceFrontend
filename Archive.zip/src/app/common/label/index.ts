export * from './label.common'
