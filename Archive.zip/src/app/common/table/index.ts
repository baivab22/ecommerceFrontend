export * from './table.common'
