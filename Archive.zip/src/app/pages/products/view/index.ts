export * from './[productId]'
