export * from './addProduct.page'
