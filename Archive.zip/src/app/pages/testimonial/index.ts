export * from './testimonial.component'
