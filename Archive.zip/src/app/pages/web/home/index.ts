export * from './home.component'
