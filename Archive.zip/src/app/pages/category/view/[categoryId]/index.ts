export * from './categoryId.page'
