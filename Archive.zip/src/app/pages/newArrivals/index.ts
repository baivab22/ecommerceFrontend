export * from './newArrivals.page'
