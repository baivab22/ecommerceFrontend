export * from './bestSelling.component'
