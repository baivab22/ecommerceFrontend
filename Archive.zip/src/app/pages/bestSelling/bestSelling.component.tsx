import React, {useEffect, useState, useCallback} from 'react'
import {useDispatch} from 'src/store'

import {
  getProductListAction,
  delteProductAction
} from '../products/product.slice'
import {useSelector} from 'react-redux'
import {
  Box,
  Button,
  HStack,
  SearchField,
  SelectField,
  Table
} from 'src/app/common'
import { useRouter } from 'next/router'
import {toast} from 'react-hot-toast'
import {getCategoryListAction} from '../category/category.slice'
import {useDebounceValue, useMedia} from 'src/hooks'
import OptimizedImage from '../../common/OptimizedImage/OptimizedImage.component'
export const BestSellingPage = () => {
  const router = useRouter()
  const dispatch = useDispatch()
  const [searchTxt, setSearchTxt] = useState('')
  const [bestSellingProducts, setBestSellingProducts] = useState([])

  const {data}: any = useSelector((state: any) => state.product)

  const [category, setCategory] = useState<any>([])
  const [selectedCateory, setSelectedCategory] = useState<any>('')
  const {categoryData}: any = useSelector((state: any) => state.category)

  useEffect(() => {
    dispatch(
      getCategoryListAction({
        onSuccess: () => console.log('categoryList fetch Successfully')
      })
    )
  }, [])

  useEffect(() => {
    console.log('all product', data)
    const bestSellingProductsss = data?.filter((item: any, index: number) => {
      return item.isBestSelling === true
    })

    setBestSellingProducts(bestSellingProductsss)
  }, [data])

  console.log(categoryData, 'category data called')

  useEffect(() => {
    // console.log(categoryData, 'caetgory data called')
    const mappedCategory = categoryData?.map((item: any, index: number) => {
      console.log(item, 'caetgory item')
      return {
        id: item.id,
        label: item.name,
        value: item.name,
        subCategory: item.subCategories
      }
    })

    // const allCategory = [
    //   {},
    //   mappedCategory
    // ]

    // console.log(mappedCategory, 'mapped category from products')
    mappedCategory?.unshift({
      id: '',
      label: 'All',
      value: '',
      subCategory: ''
    })

    setCategory(mappedCategory)
  }, [categoryData])

  useEffect(() => {
    getProductListAction({
      onSuccess: () => {},
      query: {isNewArrivals: true}
    })
  }, [])

  const handleSearch = (e: any) => {
    // console.log(e.target.value, 'searchValue')
    setSearchTxt(e.target.value)

    // const debounceValue = useDebounceValue(e.target.value)
  }

  useEffect(() => {
    console.log(selectedCateory, 'selected category name')

    dispatch(
      getProductListAction({
        onSuccess: () => {},
        query: {isBestSelling: true}
      })
    )
  }, [searchTxt, selectedCateory])

  console.log(data?.length, 'data length')
const media=useMedia();
  return (
    <div>
      <Box>
        <HStack justify="space-between" gap={'$4'} style={{margin: '20px 0'}}>
          {/* <Button title="Add Product" onClick={() => navigate('add')}></Button> */}

          {
                !media.md  &&    <SearchField
            placeholder="Search Your Product"
            onChange={handleSearch}
          ></SearchField>
          }
      Filter Product By
          <SelectField
            // defaultValue={category?.[0]}
            options={category}
            value={selectedCateory}
          
            // width="320px"
                        width={!media.md?"320px":"unset"}
            onChangeValue={(data) => setSelectedCategory(data)}
            placeholder={' Category'}
          />
        </HStack>


              {
                media.md  &&    <SearchField
            placeholder="Search Your Product"
            onChange={handleSearch}
          ></SearchField>
          }

        <Table
          columns={[
            {
              field: 'name',
              name: 'Name',
              render: (datas) => {
                return <div>{datas}</div>
              }
            },
            {
              field: 'originalPrice',
              name: 'Price',
              render: (datas) => <div>{datas}</div>
            },
            {
              field: 'originalPrice',
              name: 'Original Price',
              render: (datas) => <div>{datas}</div>
            },
            {
              field: 'discountPercentage',
              name: 'Discounted Price',
              render: (datas) => <div>{datas}</div>
            },
            {
              field: 'image',
              name: 'Images',
              render: (datas) => (
                <div>
                  {
                    <OptimizedImage
                      src={datas?.[0]?.url}
                      alt="Product image"
                      width={100}
                      height={70}
                      style={{height: '70px', width: '100px'}}
                    />
                  }
                </div>
              )
            }
          ]}
          data={bestSellingProducts && bestSellingProducts}
          actions={{
            onView: (item: any) => {
              router.push(`/dash-best-selling/view/${item.id}`)
            },

            onEdit: (item: any) => {
              router.push(`/dash-best-selling/update/${item.id}`)
            },
            onDelete: (item: any, onCloseModalHandler) => {
              //   console.log(item.id, 'item to be deleted')

              dispatch(
                delteProductAction({
                  productId: item.id,
                  onSuccess: (data: any) => {
                    onCloseModalHandler()
                    toast.success('Product deleted successfully')
                    dispatch(
                      getProductListAction({
                        onSuccess: () => {}
                      })
                    )
                  }
                })
              )
            }
          }}
          pagination={{
            totalCount: Number(data?.length ?? 1),
            perPage: Number(5)
          }}

             pageFe={true}
        />
      </Box>
    </div>
  )
}
