export * from './banners.component'
 