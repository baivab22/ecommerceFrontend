export * from './register.page'
