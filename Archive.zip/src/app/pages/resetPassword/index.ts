export * from './resetPassword.page'
