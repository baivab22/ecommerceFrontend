export const ROLES = {
  USER: 'USER',
  ADMIN: 'ADMIN'
}

type UserRoles = {
  [key: string]: {
    access: string[]
  }
}

export const USER_ROLES: UserRoles = {
  ADMIN: {
    access: [
      '/register',
      '/login',
      '/reset-password',
      '/products/*',
      '/dash-category/*',
      '/dash-subCategory/*',
      '/dash-new-arrivals/*',
      '/dash-best-selling/*',
      '/dash-banners/*',
      '/dash-product/*',
      '/sample',
      '/product/*',
      '/home/*',
      '/dash-testimonial/*',
      '/dash-shopByBudget/*',
      '/cart/*',
      '/dash-orders/*',
      '/return-policy',
      '/shipping-policy',
      '/dash-social-links/*',
      '/orderDetails/*',
      '/dash-subCategorynested/*',
      '/my-profile/*',
      '/contact-us',
      '/about-us',
      '/privacy-policy',
      '/user-data-deletion-instructions',
      '/styling-guide',
      '/dash-hot-selling/*',
      '/dash-holiday-mode/*',
      '/dash-selling-analysis/*',
      '/dash-mark-shipped/*',
      '/dash-emailMarketing/*',
      '/dash-config/*'
    ]
  },
  USER: {
    access: [
      '/register',
      '/login',
      '/reset-password',
      '/sample',
      '/business/*',
      '/home/*',
      // '/banners/*',
      // '/testimonial/*',
      // '/shopByBudget/*',
      '/cart/*',
      '/orders/*',
      // '/dash-product/*',
      '/product/*',
      'holiday-mode/*',
      '/return-policy',
      '/shipping-policy',
      'orderDetails/*',
       '/product/*',
      // '/dash-subCategorynested/*',
          '/my-profile/*',
              '/contact-us',
      '/about-us',
      '/privacy-policy',
              '/user-data-deletion-instructions',
      '/styling-guide',
      //  'dash-holiday-mode/*'
    ]
  }
}
